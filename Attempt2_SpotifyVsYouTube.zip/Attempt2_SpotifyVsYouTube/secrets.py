# spotify tokens of the client and Id

spotify_token = ""
spotify_user_id =""